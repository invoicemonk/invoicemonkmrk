'use client'

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface RedirectProps {
  to: string;
}

export const Redirect = ({ to }: RedirectProps) => {
  const router = useRouter();
  
  useEffect(() => {
    router.replace(to);
  }, [router, to]);
  
  return null;
};
