export { default as FreelancingGuideContent } from './FreelancingGuideContent';
