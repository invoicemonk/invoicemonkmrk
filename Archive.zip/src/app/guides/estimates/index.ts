export { default as EstimatesGuideContent } from './EstimatesGuideContent';
