import { notFound } from 'next/navigation';
import { useMemo } from 'react';
import { Layout } from '@/components/layout/Layout';
import { GuideHero, ConceptGrid, ArticleList, GuideCTA, GuideFAQ, GuideCrossLink } from '@/components/guides';
import { getPillarBySlug, getClusterPostsForPillar } from '@/data/topicalMap';
import { blogPosts } from '@/data/blogPosts';

export default function EstimatesGuide() {
  const pillar = getPillarBySlug('estimates');
  
  const articles = useMemo(() => {
    if (!pillar) return [];
    const slugs = getClusterPostsForPillar(pillar.id);
    return blogPosts.filter(post => slugs.includes(post.slug));
  }, [pillar]);

  if (!pillar) {
    return notFound();
  }

  const breadcrumbs = [
    { name: 'Home', url: '/' },
    { name: 'Guides', url: '/guides' },
    { name: pillar.title, url: `/guides/${pillar.slug}` }
  ];

  return (
    <Layout>
<GuideHero pillar={pillar} />
      <ConceptGrid pillar={pillar} />
      <GuideCrossLink pillar={pillar} />
      <ArticleList pillar={pillar} articles={articles} />
      <GuideCTA pillar={pillar} />
      <GuideFAQ pillar={pillar} />
    </Layout>
  );
}
