export { default as InvoicingGuideContent } from './InvoicingGuideContent';
