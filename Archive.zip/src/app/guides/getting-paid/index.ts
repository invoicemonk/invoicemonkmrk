export { default as GettingPaidGuideContent } from './GettingPaidGuideContent';
